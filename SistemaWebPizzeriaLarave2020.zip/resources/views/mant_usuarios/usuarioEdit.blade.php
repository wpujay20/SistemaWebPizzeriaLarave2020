@extends('../layouts/plantilla_mantenimientos')


@section('titulo')
Mantenimientos Pizzeria "La Buena Pizza"
@endsection

@section('cuerpo_seccion')

    {{$usuario_edit}}

@endsection


@section('zonaBotones')
    

@endsection