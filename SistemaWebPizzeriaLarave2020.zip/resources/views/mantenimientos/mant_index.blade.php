@extends('../layouts/plantilla_mantenimientos')


@section('titulo')
Mantenimientos Pizzeria "La Buena Pizza"
@endsection


@section('cuerpo_seccion')
    <div class="mensaje">Bienvenido a los Mantenimientos de "La Buena Pizza" <div>


@endsection



