


<?php $__env->startSection('titulo'); ?>
Mantenimientos Pizzeria "La Buena Pizza"
<?php $__env->stopSection(); ?>


<?php $__env->startSection('cuerpo_seccion'); ?>
    <div class="mensaje">Bienvenido a los Mantenimientos de "La Buena Pizza" <div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('../layouts/plantilla_mantenimientos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SistemaWebPizzeriaLarave2020\resources\views/mantenimientos/mant_index.blade.php ENDPATH**/ ?>