


<?php $__env->startSection('titulo'); ?>
Mantenimientos Pizzeria "La Buena Pizza"
<?php $__env->stopSection(); ?>


<?php $__env->startSection('cuerpo_seccion'); ?>

    <table id="tablaCRUD" class="table table-striped table-bordered" style="width:100%";>

    <thead>
        <tr>
            <th>Id</th>
            <th>TipoUsuario</th>
            <th>Correo</th>
            <th>Contraseña</th>
            <th>Estado</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>DNI</th>
            <th>Telefono</th>
            <th>Eliminar</th>
            <th>Editar</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $listaUsuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($i->usuario_id); ?></td>
            <td><?php echo e($i->tipo_nombre); ?></td>
            <td><?php echo e($i->usu_correo); ?></td>
            <td><?php echo e($i->usu_pass); ?></td>
            <td><?php echo e($i->usu_estado); ?></td>
            <td><?php echo e($i->per_nombres); ?></td>
            <td><?php echo e($i->per_apellidos); ?></td>
            <td><?php echo e($i->per_dni); ?></td>
            <td><?php echo e($i->per_telefono); ?></td>
            <th> <a href="<?php echo e(route("usuarios.edit", $i->persona_id)); ?>" name="editar" class="btn btn-warning"> Editar </a></th>
            <th><a href="" name="editar" class="btn btn-danger"> Eliminar </a></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>






<?php $__env->startSection('zonaBotones'); ?>
    
<button type="button" class="btn btn-success" data-toggle="modal" data-target=".bd-example-modal-lg">Crear Nuevo Usuario</button>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">


        <form method="post" action="usuarios">
            <?php echo e(csrf_field()); ?>


            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Crear Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                            <div class="form-group">
                                <label>Tipo de Usuario</label>
                                <select class="form-control" name="tipo_usuario">
                                    <?php $__currentLoopData = $listatipo_usuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->tipousu_id); ?>"> <?php echo e($key->tipo_nombre); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                            </div>
                            <div class="form-group">
                                <label > Correo </label>
                                <input name="correo" type="email" class="form-control"aria-describedby="emailHelp" placeholder="Ingresar Correo">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Contrsaeña</label>
                                <input name="contra" type="password" class="form-control" placeholder="Contraseña">
                            </div>
                            <div class="form-group">
                                <label > Nombres </label>
                                <input name="nombre" type="text" class="form-control"placeholder="Ingresar Nombres">
                            </div>
                            <div class="form-group">
                                <label > Apellidos </label>
                                <input name="apellido" type="text" class="form-control"placeholder="Ingresar Apellidos">
                            </div>
                            <div class="form-group">
                                <label > DNI </label>
                                <input name="dni" type="text" class="form-control"placeholder="Ingresar DNI">
                            </div>
                            <div class="form-group">
                                <label > Telefono </label>
                                <input name="telefono" type="text" class="form-control"placeholder="Ingresar Telefono">
                            </div>
                
                    </div>
                    <div class="modal-footer">
                        <input type="submit" class="btn btn-primary" value="Crear"/>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
                    
                    </div>
                
                    </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('../layouts/plantilla_mantenimientos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SistemaWebPizzeriaLarave2020\resources\views/mant_usuarios/MantUsuariosIndex.blade.php ENDPATH**/ ?>