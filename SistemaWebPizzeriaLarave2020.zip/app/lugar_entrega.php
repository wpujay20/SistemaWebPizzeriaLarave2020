<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lugar_entrega extends Model
{
    //
}
