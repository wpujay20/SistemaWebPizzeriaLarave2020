<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipo_pizza extends Model
{
    //
}
