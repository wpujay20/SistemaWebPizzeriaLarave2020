<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class personal_entrega extends Model
{
    //
}
