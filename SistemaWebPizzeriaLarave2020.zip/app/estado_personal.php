<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class estado_personal extends Model
{
    //
}
